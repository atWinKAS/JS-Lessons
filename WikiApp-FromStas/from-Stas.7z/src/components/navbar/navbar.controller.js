'use strict';

angular.module('promise')
  .controller('NavbarCtrl', function ($scope) {
    $scope.date = new Date();
  });
