'use strict';

angular.module('promise')
  .controller('MainCtrl', function ($scope, $http, $sce, $q) {

      $scope.text = "";
      $scope.getData = function () {
          /*var url = 'http://en.wikipedia.org/w/api.php?action=parse&page=' + $scope.text + '&prop=text&section=0&format=json&callback=JSON_CALLBACK';

          $http.jsonp(url).then(function (data) {
              $scope.content = $sce.trustAsHtml(data.data.parse.text["*"]);
          })*/
          getArticle($scope.text).then(function (text) {
              $scope.content = $sce.trustAsHtml(text);
          });
      };

      var cache = {};
      function getArticle(text) {
          if (cache[$scope.text])
              return $q.when(cache[$scope.text])
          else {
              var url = 'http://en.wikipedia.org/w/api.php?action=parse&page=' + text + '&prop=text&section=0&format=json&callback=JSON_CALLBACK';

              return cache[$scope.text] = $http.jsonp(url).then(function (response) {
                  
                  return cache[$scope.text] = response.data.parse.text["*"];
              })

          }
      };
      
  });


