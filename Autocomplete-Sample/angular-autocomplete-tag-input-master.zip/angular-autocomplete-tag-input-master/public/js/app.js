/**
 * Created by Sandeep on 16/10/14.
 */
angular.module('com.htmlxprs.autocomplete',['com.htmlxprs.autocomplete.directives','com.htmlxprs.autocomplete.controllers']);