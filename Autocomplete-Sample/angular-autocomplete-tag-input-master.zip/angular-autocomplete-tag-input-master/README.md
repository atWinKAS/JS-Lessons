AngularJS AutoComplete Tag Input
================================
A demo app showing the usage of AngularJS autocomplete tag input widget.

To run the app do the following:

1. Run `npm install`
2. Run `node bin/www`
3. Access the app at `http://localhost:8000`